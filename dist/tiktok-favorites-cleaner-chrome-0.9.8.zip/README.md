# TikTok Favorites Cleaner (local)

Version 0.9.8: omite contradicciones peligrosas, captura campos seguros de la mutación y espera a que la red relevante quede inactiva después de cada clic. Las rutas de analítica no se cuentan como mutaciones.

Extensión MV3 experimental para Chrome/Chromium (v0.9.8). Está pensada para limpiar videos guardados de la cuenta del usuario sin Playwright y sin servidor externo.

## Cómo funciona

- Lee la lista de guardados con la sesión abierta en TikTok.
- Cambia de video mediante la navegación interna de la SPA de TikTok (`history.pushState`/`popstate`) y pulsa el control real de guardar/quitar guardar; no solicita una página HTML nueva para cada video.
- Reconoce publicaciones de fotos (`/photo/`) y evita repetir la navegación cuando la SPA de TikTok no cambia la ruta solicitada.
- Registra y prueba automáticamente varias estrategias de recuperación cuando TikTok cambia la ruta pero no monta el contenido: refresco SPA, rebote por `/`, reactivación del DOM y navegación completa como último recurso.
- La verificación registra el cursor anterior y siguiente, el número real de página, elementos nuevos, tiempos y cambios de cursor para detectar ciclos o respuestas repetidas.
- Cuando la lista autenticada contradice el texto del botón, omite el elemento sin hacer clic para evitar volver a guardarlo. Una respuesta HTTP exitosa no se interpreta por sí sola como una eliminación.
- Envía el clic mediante entrada de navegador cuando Chrome lo permite, con respaldo DOM, para evitar que cambie únicamente el estado visual de React.
- Observa solicitudes y respuestas de red de TikTok, incluyendo método, transporte y nombres de campos del cuerpo (nunca valores, cookies ni tokens).
- Trabaja automáticamente por lotes; no tienes que seleccionar videos uno por uno.
- Sin fechas, cada lote empieza por los primeros videos que TikTok devuelve. Con fechas, sigue paginando hasta reunir el lote que cumple el filtro.
- Puede verificar la lista completa al terminar.
- Se detiene ante respuestas 401, 403, 429, CAPTCHA o mensajes de riesgo, sin continuar recargando.
- Guarda hasta 500 eventos de diagnóstico, incluyendo la pestaña worker, navegación, carga del reproductor, estado del botón y respuestas de mutación.

## Instalación local

1. Abre `chrome://extensions`.
2. Activa **Modo de desarrollador**.
3. Pulsa **Cargar descomprimida**.
4. Selecciona esta carpeta.
5. Abre TikTok, inicia sesión y usa el botón **🔖 Abrir limpiador**. Si ya tenías una versión anterior, pulsa **Recargar** en `chrome://extensions` antes de probar.
6. Chrome puede mostrar un aviso indicando que la extensión está depurando una pestaña; es necesario para enviar un clic de navegador equivalente al clic físico. Si no lo permite, la extensión conserva el respaldo DOM y lo deja registrado.

## Prueba recomendada

Empieza con `Lote = 1` y un rango de fechas estrecho. Si el DOM no expone la etiqueta de estado, el elemento se omitirá de forma segura. La opción **Permitir estado desconocido** existe como último recurso y puede volver a guardar un video si TikTok no permite saber si el botón está activo; debe permanecer desactivada durante la primera prueba. Después puedes subir el lote a 30.

## Diagnóstico

Abre **Logs detallados** dentro del panel. Usa **Descargar** y conserva el archivo si la operación se queda detenida. Los logs no contienen cookies ni tokens; sí incluyen rutas de TikTok, estados HTTP y mensajes de error. El watchdog avisa tras 60 segundos sin progreso y detiene la operación tras 3 minutos para evitar bucles infinitos.

## Límites

Quita la cuota artificial de una extensión comercial, pero no elimina los límites de frecuencia de TikTok. No intenta saltarse bloqueos, CAPTCHA ni verificaciones.
